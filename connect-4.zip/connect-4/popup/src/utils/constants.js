export const CONFIG_URL = './config_signed.bin';
export const HD_HARDENED = 0x80000000;